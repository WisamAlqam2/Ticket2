﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Logic
{
    public class Food
    {
        public const double TAX = 2.00;

        public string FoodName;
        public double PriceFood;
        public string Extra;
    }
}
