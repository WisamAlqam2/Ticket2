﻿using System;

namespace Bussiness_Logic
{
    public class Drink
    {
        public const double TAX = 2.00;

        public string DrinkName;
        public double PriceDrink;

            public string CheckVailedInput(string inputFromUser)
            {
                if (string.IsNullOrEmpty(inputFromUser))
                {
                    throw new Exception("null");
                }

                if (inputFromUser == "y")
                {
                    Console.WriteLine("\n");
                    Console.WriteLine("Ok, What Drink would you like?");
                    Console.WriteLine("Drink List");
                    return "y";


                }
                else if (inputFromUser == "n")
                {


                    return "n ";
                }
                else
                {
                    return "InvalidInput";
                }
            }

        }
    }
