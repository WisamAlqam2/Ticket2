﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Logic
{
    public class Menu
    {
        public List<Drink> Drinks { get; set; }
        public List<Food> Foods { get; set; }



        public  Menu GetMenuList(string type)
        {
            var menu = new Menu();

            if (type == "D")
            {
                var drinkList = new List<Drink>
                {
                    new Drink { DrinkName = "Coffee",           PriceDrink = 25 },
                    new Drink { DrinkName = "Coffee With Milk", PriceDrink = 30 },
                    new Drink { DrinkName = "Tea",              PriceDrink = 20 },
                    new Drink { DrinkName = "Green Tea",        PriceDrink = 25 },
                    new Drink { DrinkName = "Cola With Ice",    PriceDrink = 30 },
                    new Drink { DrinkName = "Lemon",            PriceDrink = 20 },
                    new Drink { DrinkName = "Mint lemon",       PriceDrink = 20 }

                };

                menu.Drinks = drinkList;

                return menu;


            }

            if (type == "F")
            {
                var foodList = new List<Food>
                 {
                new Food { FoodName = "kitech",          PriceFood = 25 },
                new Food { FoodName = "Fish",            PriceFood = 30 },
                new Food { FoodName = "Burgar",          PriceFood = 20 },
                new Food { FoodName = "kebab",           PriceFood = 25 },
                new Food { FoodName = "Hummus and meat", PriceFood = 30 },
                new Food { FoodName = "Prost",           PriceFood = 20 }
                 };

                menu.Foods = foodList;

                return menu;
            }
            return null;
        }
    }
}
