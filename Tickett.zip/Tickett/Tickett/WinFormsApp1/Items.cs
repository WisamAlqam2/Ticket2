﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WinFormsApp1
{
    public partial class frm_item : Form
    {

        const double price_chickens = 40;
        const double price_Fish = 45;
        const double price_Burgar = 23;
        const double price_Kebab = 77;
        const double price_Hummas = 12;
        const double price_Prost = 21;
        const double price_Coffee = 2;
        const double price_Coffeewithmilk = 4;
        const double price_Tea = 3;
        const double price_Green = 1;
        const double price_Colawithice = 6;
        const double price_Lemon = 8;
        const double price_Mintlemon = 9;

        public frm_item()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }
        private void EnableTextBoxes()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control Control in controls)
                    if (Control is TextBox)
                        (Control as TextBox).Enabled = false;
                    else
                        func(Control.Controls);
            };
            func(Controls);
        }


        private void frm_item_Load(object sender, EventArgs e)
        {
            cmb_payment.Items.Add("");
            cmb_payment.Items.Add("Cash");
            cmb_payment.Items.Add("Cash On Delivery");

            EnableTextBoxes();

        }

        private void cmb_payment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_payment.Text == "cash")
            {
                txt_payment.Enabled = true;
                txt_payment.Text = "";
                txt_payment.Focus();
            }
            else if (cmb_payment.Text == "Cash On Delivery")
            {
                txt_Name.Enabled = true;
                txt_Address.Enabled = true;
                txt_Number.Enabled = true;
                txt_Name.Text = "";
                txt_Address.Text = "";
                txt_Number.Text = "";
                txt_Name.Focus();
                txt_Address.Focus();
                txt_Number.Focus();
            }
            else
            {
                txt_payment.Enabled = false;
                txt_payment.Text = "0";
            }

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                txt_Fish.Enabled = true;
                txt_Fish.Text = "";
                txt_Fish.Focus();
            }
            else
            {
                txt_Fish.Enabled = false;
                txt_Fish.Text = "0";
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                txt_Burgar.Enabled = true;
                txt_Burgar.Text = "";
                txt_Burgar.Focus();
            }
            else
            {
                txt_Burgar.Enabled = false;
                txt_Burgar.Text = "0";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                txt_Kebab.Enabled = true;
                txt_Kebab.Text = "";
                txt_Kebab.Focus();
            }
            else
            {
                txt_Kebab.Enabled = false;
                txt_Kebab.Text = "0";
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txt_Kitchen.Enabled = true;
                txt_Kitchen.Text = "";
                txt_Kitchen.Focus();
            }
            else
            {
                txt_Kitchen.Enabled = false;
                txt_Kitchen.Text = "0";
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                txt_Hummus.Enabled = true;
                txt_Hummus.Text = "";
                txt_Hummus.Focus();
            }
            else
            {
                txt_Hummus.Enabled = false;
                txt_Hummus.Text = "0";
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                txt_Prost.Enabled = true;
                txt_Prost.Text = "";
                txt_Prost.Focus();
            }
            else
            {
                txt_Prost.Enabled = false;
                txt_Prost.Text = "0";
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked == true)
            {
                txt_Coffee.Enabled = true;
                txt_Coffee.Text = "";
                txt_Coffee.Focus();
            }
            else
            {
                txt_Coffee.Enabled = false;
                txt_Coffee.Text = "0";
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
                txt_CoffeeW.Enabled = true;
                txt_CoffeeW.Text = "";
                txt_CoffeeW.Focus();
            }
            else
            {
                txt_CoffeeW.Enabled = false;
                txt_CoffeeW.Text = "0";
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox12.Checked == true)
            {
                txt_Tea.Enabled = true;
                txt_Tea.Text = "";
                txt_Tea.Focus();
            }
            else
            {
                txt_Tea.Enabled = false;
                txt_Tea.Text = "0";
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked == true)
            {
                txt_Greentea.Enabled = true;
                txt_Greentea.Text = "";
                txt_Greentea.Focus();
            }
            else
            {
                txt_Greentea.Enabled = false;
                txt_Greentea.Text = "0";
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox10.Checked == true)
            {
                txt_ColaWithIce.Enabled = true;
                txt_ColaWithIce.Text = "";
                txt_ColaWithIce.Focus();
            }
            else
            {
                txt_ColaWithIce.Enabled = false;
                txt_ColaWithIce.Text = "0";
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                txt_Lemon.Enabled = true;
                txt_Lemon.Text = "";
                txt_Lemon.Focus();
            }
            else
            {
                txt_Lemon.Enabled = false;
                txt_Lemon.Text = "0";
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
            {
                txt_Mintlemon.Enabled = true;
                txt_Mintlemon.Text = "";
                txt_Mintlemon.Focus();
            }
            else
            {
                txt_Mintlemon.Enabled = false;
                txt_Mintlemon.Text = "0";
            }
        }
        private void buttonbtn_total_Click(object sender, EventArgs e)
        {
            double[] itemcost = new double[100];
            itemcost[0] = Convert.ToDouble(txt_Kitchen.Text) * price_chickens;
            itemcost[1] = Convert.ToDouble(txt_Fish.Text) * price_Fish;
            itemcost[2] = Convert.ToDouble(txt_Burgar.Text) * price_Burgar;
            itemcost[3] = Convert.ToDouble(txt_Kebab.Text) * price_Kebab;
            itemcost[4] = Convert.ToDouble(txt_Hummus.Text) * price_Hummas;
            itemcost[5] = Convert.ToDouble(txt_Prost.Text) * price_Prost;
            itemcost[6] = Convert.ToDouble(txt_Coffee.Text) * price_Coffee;
            itemcost[7] = Convert.ToDouble(txt_CoffeeW.Text) * price_Coffeewithmilk;
            itemcost[8] = Convert.ToDouble(txt_Tea.Text) * price_Tea;
            itemcost[9] = Convert.ToDouble(txt_Greentea.Text) * price_Green;
            itemcost[10] = Convert.ToDouble(txt_ColaWithIce.Text) * price_Colawithice;
            itemcost[11] = Convert.ToDouble(txt_Lemon.Text) * price_Lemon;
            itemcost[12] = Convert.ToDouble(txt_Mintlemon.Text) * price_Mintlemon;

            double total, payment, cost;
            if (cmb_payment.Text == "Cash")
            {
                total = itemcost[0] + itemcost[1] + itemcost[2]
                    + itemcost[3] + itemcost[4] + itemcost[5]
                    + itemcost[6] + itemcost[7] + itemcost[8]
                    + itemcost[9] + itemcost[10] + itemcost[11]
                + itemcost[12];

                Ibl_result.Text = Convert.ToString(total);

                payment = Convert.ToInt32(txt_payment.Text);
                cost = payment - total;
                Ibl_changeresult.Text = Convert.ToString(cost);
            }
            else
            {
                total = itemcost[0] + itemcost[1] + itemcost[2]
                 + itemcost[3] + itemcost[4] + itemcost[5]
                 + itemcost[6] + itemcost[7] + itemcost[8]
                 + itemcost[9] + itemcost[10] + itemcost[11]
             + itemcost[12];

                Ibl_result.Text = Convert.ToString(total);
            }

        }



        private void button2_Click(object sender, EventArgs e)
        {
            RestTexBox();
            RestCheckBox();
        }
        private void RestTexBox()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control control in controls)
                {
                    if (control is TextBox)
                        (control as TextBox).Text = "0";
                    else

                        func(controls);

                }
            };

            func(Controls);
        }
        private void RestCheckBox()
        {
            Action<Control.ControlCollection> func = null;
            func = (controls) =>
            {
                foreach (Control control in controls)
                {
                    if (control is CheckBox)
                        (control as CheckBox).Text = "0";
                    else
                        func(controls);

                }
            };

            func(Controls);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Choosing Our Resturant " + txt_Name +
                "We Will Delver Your Order At" + txt_Address +
                "We want Your Information" + txt_Number);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Confirm you want to exit the system", "Exit System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Invoke(new Action(() => System.Windows.Forms.Application.Exit()));
            }
        }


        private void txt_payment_TextChanged(object sender, EventArgs e)
        {
            double paymentAmount;

            if (double.TryParse(txt_payment.Text, out paymentAmount))
            {
                double totalCost = CalculateTotalCost(); // Implement your logic to calculate total cost
                double change = paymentAmount - totalCost;

                if (change >= 0)
                {
                    Ibl_changeresult.Text = "Change: " + change.ToString("C"); // Display as currency
                }
                else
                {
                    Ibl_changeresult.Text = "Amount Owed: " + (-change).ToString("C");
                }
            }
            else
            {
                Ibl_changeresult.Text = string.Empty;
            }
        }

       
            private double CalculateTotalCost()
            {
            double totalCost = frm_item.price_chickens + frm_item.price_Fish + frm_item.price_Burgar
                              + frm_item.price_Kebab + frm_item.price_Hummas + frm_item.price_Prost
                              + frm_item.price_Coffee + frm_item.price_Coffeewithmilk + frm_item.price_Tea
                              + frm_item.price_Green + frm_item.price_Colawithice + frm_item.price_Lemon
                              + frm_item.price_Mintlemon;
                return totalCost;
            }


        }



    }








