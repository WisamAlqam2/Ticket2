﻿
namespace WinFormsApp1
{
    partial class frm_item
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new System.Windows.Forms.GroupBox();
            label4 = new System.Windows.Forms.Label();
            txt_Prost = new System.Windows.Forms.TextBox();
            txt_Hummus = new System.Windows.Forms.TextBox();
            txt_Kebab = new System.Windows.Forms.TextBox();
            txt_Burgar = new System.Windows.Forms.TextBox();
            checkBox6 = new System.Windows.Forms.CheckBox();
            checkBox5 = new System.Windows.Forms.CheckBox();
            checkBox4 = new System.Windows.Forms.CheckBox();
            checkBox3 = new System.Windows.Forms.CheckBox();
            checkBox2 = new System.Windows.Forms.CheckBox();
            checkBox1 = new System.Windows.Forms.CheckBox();
            txt_Fish = new System.Windows.Forms.TextBox();
            txt_Kitchen = new System.Windows.Forms.TextBox();
            groupBox2 = new System.Windows.Forms.GroupBox();
            label6 = new System.Windows.Forms.Label();
            txt_CoffeeW = new System.Windows.Forms.TextBox();
            txt_Tea = new System.Windows.Forms.TextBox();
            txt_Greentea = new System.Windows.Forms.TextBox();
            txt_ColaWithIce = new System.Windows.Forms.TextBox();
            txt_Lemon = new System.Windows.Forms.TextBox();
            txt_Mintlemon = new System.Windows.Forms.TextBox();
            txt_Coffee = new System.Windows.Forms.TextBox();
            checkBox8 = new System.Windows.Forms.CheckBox();
            checkBox9 = new System.Windows.Forms.CheckBox();
            checkBox10 = new System.Windows.Forms.CheckBox();
            checkBox11 = new System.Windows.Forms.CheckBox();
            checkBox12 = new System.Windows.Forms.CheckBox();
            checkBox13 = new System.Windows.Forms.CheckBox();
            checkBox14 = new System.Windows.Forms.CheckBox();
            label1 = new System.Windows.Forms.Label();
            buttonbtn_total = new System.Windows.Forms.Button();
            txt_Name = new System.Windows.Forms.TextBox();
            txt_Number = new System.Windows.Forms.TextBox();
            txt_Address = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            cmb_payment = new System.Windows.Forms.ComboBox();
            lbl_payment = new System.Windows.Forms.Label();
            Ibl_changeresult = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            Ibl_result = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            txt_payment = new System.Windows.Forms.TextBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txt_Prost);
            groupBox1.Controls.Add(txt_Hummus);
            groupBox1.Controls.Add(txt_Kebab);
            groupBox1.Controls.Add(txt_Burgar);
            groupBox1.Controls.Add(checkBox6);
            groupBox1.Controls.Add(checkBox5);
            groupBox1.Controls.Add(checkBox4);
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(txt_Fish);
            groupBox1.Controls.Add(txt_Kitchen);
            groupBox1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            groupBox1.Location = new System.Drawing.Point(26, 33);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(294, 375);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Food";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(198, 35);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(82, 23);
            label4.TabIndex = 22;
            label4.Text = "Quantity";
            label4.Click += label4_Click_1;
            // 
            // txt_Prost
            // 
            txt_Prost.Location = new System.Drawing.Point(234, 294);
            txt_Prost.Multiline = true;
            txt_Prost.Name = "txt_Prost";
            txt_Prost.Size = new System.Drawing.Size(20, 23);
            txt_Prost.TabIndex = 21;
            // 
            // txt_Hummus
            // 
            txt_Hummus.Location = new System.Drawing.Point(234, 245);
            txt_Hummus.Multiline = true;
            txt_Hummus.Name = "txt_Hummus";
            txt_Hummus.Size = new System.Drawing.Size(20, 23);
            txt_Hummus.TabIndex = 20;
            // 
            // txt_Kebab
            // 
            txt_Kebab.Location = new System.Drawing.Point(234, 202);
            txt_Kebab.Multiline = true;
            txt_Kebab.Name = "txt_Kebab";
            txt_Kebab.Size = new System.Drawing.Size(20, 23);
            txt_Kebab.TabIndex = 19;
            // 
            // txt_Burgar
            // 
            txt_Burgar.Location = new System.Drawing.Point(234, 156);
            txt_Burgar.Multiline = true;
            txt_Burgar.Name = "txt_Burgar";
            txt_Burgar.Size = new System.Drawing.Size(20, 23);
            txt_Burgar.TabIndex = 18;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox6.Location = new System.Drawing.Point(34, 294);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new System.Drawing.Size(73, 27);
            checkBox6.TabIndex = 5;
            checkBox6.Text = "Prost";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox5.Location = new System.Drawing.Point(34, 245);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new System.Drawing.Size(185, 27);
            checkBox5.TabIndex = 4;
            checkBox5.Text = "Hummus and meat";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox4.Location = new System.Drawing.Point(34, 112);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new System.Drawing.Size(65, 27);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "Fish";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox3.Location = new System.Drawing.Point(34, 156);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new System.Drawing.Size(87, 27);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Burgar";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox2.Location = new System.Drawing.Point(34, 202);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new System.Drawing.Size(77, 27);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "kebab";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox1.Location = new System.Drawing.Point(34, 67);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new System.Drawing.Size(100, 27);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "chickens";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // txt_Fish
            // 
            txt_Fish.Location = new System.Drawing.Point(234, 112);
            txt_Fish.Multiline = true;
            txt_Fish.Name = "txt_Fish";
            txt_Fish.Size = new System.Drawing.Size(20, 23);
            txt_Fish.TabIndex = 16;
            // 
            // txt_Kitchen
            // 
            txt_Kitchen.Location = new System.Drawing.Point(234, 67);
            txt_Kitchen.Multiline = true;
            txt_Kitchen.Name = "txt_Kitchen";
            txt_Kitchen.Size = new System.Drawing.Size(20, 23);
            txt_Kitchen.TabIndex = 17;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txt_CoffeeW);
            groupBox2.Controls.Add(txt_Tea);
            groupBox2.Controls.Add(txt_Greentea);
            groupBox2.Controls.Add(txt_ColaWithIce);
            groupBox2.Controls.Add(txt_Lemon);
            groupBox2.Controls.Add(txt_Mintlemon);
            groupBox2.Controls.Add(txt_Coffee);
            groupBox2.Controls.Add(checkBox8);
            groupBox2.Controls.Add(checkBox9);
            groupBox2.Controls.Add(checkBox10);
            groupBox2.Controls.Add(checkBox11);
            groupBox2.Controls.Add(checkBox12);
            groupBox2.Controls.Add(checkBox13);
            groupBox2.Controls.Add(checkBox14);
            groupBox2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            groupBox2.Location = new System.Drawing.Point(342, 33);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new System.Drawing.Size(270, 375);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Drink";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(182, 35);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(82, 23);
            label6.TabIndex = 23;
            label6.Text = "Quantity";
            // 
            // txt_CoffeeW
            // 
            txt_CoffeeW.Location = new System.Drawing.Point(224, 116);
            txt_CoffeeW.Multiline = true;
            txt_CoffeeW.Name = "txt_CoffeeW";
            txt_CoffeeW.Size = new System.Drawing.Size(20, 23);
            txt_CoffeeW.TabIndex = 23;
            // 
            // txt_Tea
            // 
            txt_Tea.Location = new System.Drawing.Point(224, 160);
            txt_Tea.Multiline = true;
            txt_Tea.Name = "txt_Tea";
            txt_Tea.Size = new System.Drawing.Size(20, 23);
            txt_Tea.TabIndex = 22;
            // 
            // txt_Greentea
            // 
            txt_Greentea.Location = new System.Drawing.Point(224, 208);
            txt_Greentea.Multiline = true;
            txt_Greentea.Name = "txt_Greentea";
            txt_Greentea.Size = new System.Drawing.Size(20, 23);
            txt_Greentea.TabIndex = 21;
            // 
            // txt_ColaWithIce
            // 
            txt_ColaWithIce.Location = new System.Drawing.Point(224, 249);
            txt_ColaWithIce.Multiline = true;
            txt_ColaWithIce.Name = "txt_ColaWithIce";
            txt_ColaWithIce.Size = new System.Drawing.Size(20, 23);
            txt_ColaWithIce.TabIndex = 20;
            // 
            // txt_Lemon
            // 
            txt_Lemon.Location = new System.Drawing.Point(224, 294);
            txt_Lemon.Multiline = true;
            txt_Lemon.Name = "txt_Lemon";
            txt_Lemon.Size = new System.Drawing.Size(20, 23);
            txt_Lemon.TabIndex = 19;
            // 
            // txt_Mintlemon
            // 
            txt_Mintlemon.Location = new System.Drawing.Point(224, 338);
            txt_Mintlemon.Multiline = true;
            txt_Mintlemon.Name = "txt_Mintlemon";
            txt_Mintlemon.Size = new System.Drawing.Size(20, 23);
            txt_Mintlemon.TabIndex = 18;
            // 
            // txt_Coffee
            // 
            txt_Coffee.Location = new System.Drawing.Point(224, 71);
            txt_Coffee.Multiline = true;
            txt_Coffee.Name = "txt_Coffee";
            txt_Coffee.Size = new System.Drawing.Size(20, 23);
            txt_Coffee.TabIndex = 15;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox8.Location = new System.Drawing.Point(34, 338);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new System.Drawing.Size(126, 27);
            checkBox8.TabIndex = 6;
            checkBox8.Text = "Mint lemon";
            checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox9.Location = new System.Drawing.Point(34, 294);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new System.Drawing.Size(87, 27);
            checkBox9.TabIndex = 5;
            checkBox9.Text = "Lemon";
            checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox10.Location = new System.Drawing.Point(34, 245);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new System.Drawing.Size(143, 27);
            checkBox10.TabIndex = 4;
            checkBox10.Text = "Cola With Ice";
            checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            checkBox11.AutoSize = true;
            checkBox11.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox11.Location = new System.Drawing.Point(34, 112);
            checkBox11.Name = "checkBox11";
            checkBox11.Size = new System.Drawing.Size(176, 27);
            checkBox11.TabIndex = 3;
            checkBox11.Text = "Coffee With Milk";
            checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            checkBox12.AutoSize = true;
            checkBox12.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox12.Location = new System.Drawing.Point(34, 156);
            checkBox12.Name = "checkBox12";
            checkBox12.Size = new System.Drawing.Size(58, 27);
            checkBox12.TabIndex = 2;
            checkBox12.Text = "Tea";
            checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            checkBox13.AutoSize = true;
            checkBox13.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox13.Location = new System.Drawing.Point(34, 202);
            checkBox13.Name = "checkBox13";
            checkBox13.Size = new System.Drawing.Size(113, 27);
            checkBox13.TabIndex = 1;
            checkBox13.Text = "Green Tea";
            checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            checkBox14.AutoSize = true;
            checkBox14.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            checkBox14.Location = new System.Drawing.Point(34, 67);
            checkBox14.Name = "checkBox14";
            checkBox14.Size = new System.Drawing.Size(86, 27);
            checkBox14.TabIndex = 0;
            checkBox14.Text = "Coffee";
            checkBox14.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(651, 84);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(68, 22);
            label1.TabIndex = 8;
            label1.Text = "Name :";
            // 
            // buttonbtn_total
            // 
            buttonbtn_total.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            buttonbtn_total.Location = new System.Drawing.Point(833, 422);
            buttonbtn_total.Name = "buttonbtn_total";
            buttonbtn_total.Size = new System.Drawing.Size(75, 27);
            buttonbtn_total.TabIndex = 13;
            buttonbtn_total.Text = "Total";
            buttonbtn_total.UseVisualStyleBackColor = true;
            buttonbtn_total.Click += buttonbtn_total_Click;
            // 
            // txt_Name
            // 
            txt_Name.Location = new System.Drawing.Point(752, 83);
            txt_Name.Name = "txt_Name";
            txt_Name.Size = new System.Drawing.Size(100, 23);
            txt_Name.TabIndex = 15;
            // 
            // txt_Number
            // 
            txt_Number.Location = new System.Drawing.Point(752, 172);
            txt_Number.Name = "txt_Number";
            txt_Number.Size = new System.Drawing.Size(100, 23);
            txt_Number.TabIndex = 16;
            // 
            // txt_Address
            // 
            txt_Address.Location = new System.Drawing.Point(752, 128);
            txt_Address.Name = "txt_Address";
            txt_Address.Size = new System.Drawing.Size(100, 23);
            txt_Address.TabIndex = 17;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(633, 173);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(86, 22);
            label2.TabIndex = 18;
            label2.Text = "Number :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(633, 129);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(86, 22);
            label3.TabIndex = 19;
            label3.Text = "Address :";
            label3.Click += label3_Click;
            // 
            // button1
            // 
            button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(752, 422);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(75, 27);
            button1.TabIndex = 20;
            button1.Text = "Exit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button2.Location = new System.Drawing.Point(671, 422);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(75, 27);
            button2.TabIndex = 21;
            button2.Text = "Reset";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button4
            // 
            button4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button4.Location = new System.Drawing.Point(590, 422);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(75, 27);
            button4.TabIndex = 22;
            button4.Text = "Ok";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // cmb_payment
            // 
            cmb_payment.FormattingEnabled = true;
            cmb_payment.Location = new System.Drawing.Point(773, 228);
            cmb_payment.Name = "cmb_payment";
            cmb_payment.Size = new System.Drawing.Size(100, 23);
            cmb_payment.TabIndex = 23;
            cmb_payment.SelectedIndexChanged += cmb_payment_SelectedIndexChanged;
            // 
            // lbl_payment
            // 
            lbl_payment.AutoSize = true;
            lbl_payment.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbl_payment.Location = new System.Drawing.Point(618, 229);
            lbl_payment.Name = "lbl_payment";
            lbl_payment.Size = new System.Drawing.Size(149, 22);
            lbl_payment.TabIndex = 24;
            lbl_payment.Text = "Payment Method";
            // 
            // Ibl_changeresult
            // 
            Ibl_changeresult.AutoSize = true;
            Ibl_changeresult.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Ibl_changeresult.Location = new System.Drawing.Point(733, 336);
            Ibl_changeresult.Name = "Ibl_changeresult";
            Ibl_changeresult.Size = new System.Drawing.Size(119, 22);
            Ibl_changeresult.TabIndex = 25;
            Ibl_changeresult.Text = "Total Resulat";
            Ibl_changeresult.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(633, 336);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 22);
            label5.TabIndex = 26;
            label5.Text = "Change :";
            label5.Click += label5_Click;
            // 
            // Ibl_result
            // 
            Ibl_result.AutoSize = true;
            Ibl_result.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Ibl_result.Location = new System.Drawing.Point(733, 305);
            Ibl_result.Name = "Ibl_result";
            Ibl_result.Size = new System.Drawing.Size(119, 22);
            Ibl_result.TabIndex = 27;
            Ibl_result.Text = "Total Resulat";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(633, 305);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(67, 22);
            label7.TabIndex = 28;
            label7.Text = " Total :";
            // 
            // txt_payment
            // 
            txt_payment.Location = new System.Drawing.Point(773, 267);
            txt_payment.Name = "txt_payment";
            txt_payment.Size = new System.Drawing.Size(100, 23);
            txt_payment.TabIndex = 29;
            txt_payment.TextChanged += txt_payment_TextChanged;
            // 
            // frm_item
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.SkyBlue;
            ClientSize = new System.Drawing.Size(920, 487);
            Controls.Add(txt_payment);
            Controls.Add(label7);
            Controls.Add(Ibl_result);
            Controls.Add(label5);
            Controls.Add(Ibl_changeresult);
            Controls.Add(lbl_payment);
            Controls.Add(cmb_payment);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txt_Address);
            Controls.Add(txt_Number);
            Controls.Add(txt_Name);
            Controls.Add(buttonbtn_total);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "frm_item";
            Text = "Items";
            Load += frm_item_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonbtn_total;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.TextBox txt_Number;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox cmb_payment;
        private System.Windows.Forms.Label lbl_payment;
        private System.Windows.Forms.Label Ibl_changeresult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Ibl_result;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_payment;
        private System.Windows.Forms.TextBox txt_CoffeeW;
        private System.Windows.Forms.TextBox txt_Tea;
        private System.Windows.Forms.TextBox txt_Greentea;
        private System.Windows.Forms.TextBox txt_ColaWithIce;
        private System.Windows.Forms.TextBox txt_Lemon;
        private System.Windows.Forms.TextBox txt_Mintlemon;
        private System.Windows.Forms.TextBox txt_Kitchen;
        private System.Windows.Forms.TextBox txt_Fish;
        private System.Windows.Forms.TextBox txt_Coffee;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Prost;
        private System.Windows.Forms.TextBox txt_Hummus;
        private System.Windows.Forms.TextBox txt_Kebab;
        private System.Windows.Forms.TextBox txt_Burgar;
        private System.Windows.Forms.Label label6;
    }
}